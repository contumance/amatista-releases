AMATISTA Efectos digitales boutique
Carbonado Boost - macOS (VST3)

Esta versión es UNSIGNED (sin Developer ID).

INSTALACIÓN
AU (.component):
  /Library/Audio/Plug-Ins/Components/

VST3 (.vst3):
  /Library/Audio/Plug-Ins/VST3/

DESBLOQUEO (si macOS lo bloquea)
Error típico:
  "has been modified or damaged"  /  "developer cannot be verified"

Solución (Terminal) ⚙️

1) Para AU (.component):
sudo xattr -dr com.apple.quarantine "/Library/Audio/Plug-Ins/Components/Carbonado Boost.component"

2) Para VST3 (.vst3):
sudo xattr -dr com.apple.quarantine "/Library/Audio/Plug-Ins/VST3/Carbonado Boost.vst3"

Luego reinicia el DAW.

Si sigue bloqueado:
System Settings -> Privacy & Security -> Open Anyway
